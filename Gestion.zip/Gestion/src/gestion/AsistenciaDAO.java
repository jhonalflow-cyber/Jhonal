/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;
import Conexion.AdministradorBD;
import Conexion.ConexionBD;
import Conexion.MySQLBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Laptop
 */
public class AsistenciaDAO {
    private ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
    private AdministradorBD admin = new AdministradorBD(con);
    
public void insertarAsistencia(int estudianteId, Date fecha, boolean presente) {
        String sql = "INSERT INTO Asistencias (estudiante_id, fecha, presente) VALUES (?, ?, ?)";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, estudianteId);
            stmt.setDate(2, fecha);
            stmt.setBoolean(3, presente);

            stmt.executeUpdate();
            System.out.println("Asistencia insertada correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Asistencia> consultarAsistencias() {
        List<Asistencia> lista = new ArrayList<>();
        String sql = "SELECT * FROM Asistencias";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Asistencia as = new Asistencia();
                as.setId(rs.getInt("id"));
                as.setEstudianteId(rs.getInt("estudiante_id"));
                as.setFecha(rs.getDate("fecha"));
                as.setPresente(rs.getBoolean("presente"));
                lista.add(as);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void actualizarAsistencia(int id, int estudianteId, Date fecha, boolean presente) {
        String sql = "UPDATE Asistencias SET estudiante_id = ?, fecha = ?, presente = ? WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, estudianteId);
            stmt.setDate(2, fecha);
            stmt.setBoolean(3, presente);
            stmt.setInt(4, id);
            

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Asistencia actualizada correctamente.");
            } else {
                System.out.println("No existe asistencia con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarAsistencia(int id) {
        String sql = "DELETE FROM Asistencias WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Asistencia eliminada correctamente.");
            } else {
                System.out.println("No existe asistencia con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

