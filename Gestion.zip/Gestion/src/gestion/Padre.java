/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;

/**
 *
 * @author Laptop
 */
public class Padre {
    
private int id;
    private String nombre;
    private String telefono;
    private int estudianteId;

    public Padre() {}

    public Padre(int id, String nombre, String telefono, int estudianteId) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.estudianteId = estudianteId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    @Override
    public String toString() {
        return "Padre{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", telefono='" + telefono + '\'' +
                ", estudianteId=" + estudianteId +
                '}';
    }
}
