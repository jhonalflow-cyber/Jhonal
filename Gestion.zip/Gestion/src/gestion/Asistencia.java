/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;

import java.util.Date;

/**
 *
 * @author Laptop
 */
public class Asistencia {
    
private int id;
    private int estudianteId;
    private Date fecha;
    private boolean presente;

    public Asistencia() {}

    public Asistencia(int id, int estudianteId, Date fecha, boolean presente) {
        this.id = id;
        this.estudianteId = estudianteId;
        this.fecha = fecha;
        this.presente = presente;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public boolean isPresente() { return presente; }
    public void setPresente(boolean presente) { this.presente = presente; }

    @Override
    public String toString() {
        return "Asistencia{" +
                "id=" + id +
                ", estudianteId=" + estudianteId +
                ", fecha=" + fecha +
                ", presente=" + presente +
                '}';
    }
}

