/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;
import Conexion.AdministradorBD;
import Conexion.ConexionBD;
import Conexion.MySQLBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Laptop
 */
public class ProfesorDAO {
    private ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
    private AdministradorBD admin = new AdministradorBD(con);
    
    
  public void insertarProfesor(String nombre, String especialidad) {
        String sql = "INSERT INTO Profesores (nombre, especialidad) VALUES (?, ?)";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, especialidad);
            stmt.executeUpdate();
            System.out.println("Profesor insertado correctamente.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Profesor> consultarProfesores() {
        List<Profesor> lista = new ArrayList<>();
        String sql = "SELECT * FROM Profesores";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Profesor p = new Profesor();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setEspecialidad(rs.getString("especialidad"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void actualizarProfesor(int id, String nombre, String especialidad) {
        String sql = "UPDATE Profesores SET nombre = ?, especialidad = ? WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, especialidad);
            stmt.setInt(3, id);

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Profesor actualizado correctamente.");
            } else {
                System.out.println("No existe profesor con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarProfesor(int id) {
        String sql = "DELETE FROM Profesores WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Profesor eliminado correctamente.");
            } else {
                System.out.println("No existe profesor con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
