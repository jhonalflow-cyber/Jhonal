/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;
import Conexion.AdministradorBD;
import Conexion.ConexionBD;
import Conexion.MySQLBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Laptop
 */
public class PadreDAO {
    private ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
    private AdministradorBD admin = new AdministradorBD(con);
    
public void insertarPadre(String nombre, String telefono, int estudianteId) {
        String sql = "INSERT INTO Padres (nombre, telefono, estudiante_id) VALUES (?, ?, ?)";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, telefono);
            stmt.setInt(3, estudianteId);

            stmt.executeUpdate();
            System.out.println("Padre insertado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Padre> consultarPadres() {
        List<Padre> lista = new ArrayList<>();
        String sql = "SELECT * FROM Padres";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Padre p = new Padre();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setTelefono(rs.getString("telefono"));
                p.setEstudianteId(rs.getInt("estudiante_id"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void actualizarPadre(int id, String nombre, String telefono, int estudianteId) {
        String sql = "UPDATE padres SET nombre = ?, telefono = ?, estudiante_id = ?  WHERE id = ?" ;

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, telefono);
            stmt.setInt(3, estudianteId);
            stmt.setInt(4, id);

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Padre actualizado correctamente.");
            } else {
                System.out.println("No existe padre con ID: "+ id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarPadre(int id) {
        String sql = "DELETE FROM Padres WHERE id = ?" ;

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Padre eliminado correctamente.");
            } else {
                System.out.println("No existe padre con ID : " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void cargarPadresEnTabla(){
     String sql = """
            SELECT 
                p.id,
                p.nombre,
                p.telefono,
                CONCAT_WS(' ', h.nombre, h.apellido) AS parentezco
            FROM padres AS p
            INNER JOIN estudiantes AS h
                ON p.estudiante_id = h.id
        """;

        try (Connection a = admin.getConnection();
             Statement st = a.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            // 🧩 Definir columnas
            //modelo.addColumn("ID Padre");
            //modelo.addColumn("Nombre Padre");
            //modelo.addColumn("Teléfono");
            //modelo.addColumn("Hijo");

            // 🧠 Llenar filas
            while (rs.next()) {
                Object[] fila = new Object[4];
                fila[0] = rs.getInt("id");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("telefono");
                fila[3] = rs.getString("parentezco");
                //modelo.addRow(fila);
                System.out.println(fila[0]+" "+fila[1]+" "+fila[2]+" "+fila[3]);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al cargar datos: " + e.getMessage());
        }
    
    }
    
    /**
     *
     * @return
     */
    public List<Object[]> cargarPadresEnTablaOb() {
    List<Object[]> lista = new ArrayList<>();

    String sql = """
        SELECT 
            p.id,
            p.nombre,
            p.telefono,
            p.estudiante_id AS matricula,
            CONCAT_WS(' ', h.nombre, h.apellido) AS parentezco
        FROM padres AS p
        INNER JOIN estudiantes AS h
            ON p.estudiante_id = h.id
    """;

    try (Connection a = admin.getConnection();
         Statement st = a.createStatement();
         ResultSet rs = st.executeQuery(sql)) {

        while (rs.next()) {
            Object[] fila = new Object[5];
            fila[0] = rs.getInt("id");
            fila[1] = rs.getString("nombre");
            fila[2] = rs.getString("telefono");
            fila[3] = rs.getString("matricula");
            fila[4] = rs.getString("parentezco");
            lista.add(fila);
        }

    } catch (SQLException e) {
        System.out.println("❌ Error al cargar datos: " + e.getMessage());
    }

    return lista;
}
    
}