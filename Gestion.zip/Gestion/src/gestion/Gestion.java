/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestion;

import Conexion.*;
import java.sql.SQLException;
import java.util.*;
import java.sql.Date;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;


/**
 *
 * @author Laptop
 */
public class Gestion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BD dbc = new BD();
        //BD.conectar();
        
        ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
        AdministradorBD admin = new AdministradorBD(con);
        try{
        admin.getConnection();
        System.out.println("Conexion exitosa");
    }catch(SQLException e)
       {
        System.out.println("Error");
       }
    
    //Prueba de datos para Estudiantes
    EstudianteDAO dao = new EstudianteDAO();
        List<Estudiante> estudiantes = dao.consultarEstudiantes();

        for (Estudiante est : estudiantes) {
            System.out.println(est);
        }
        
     //Insertar
     //dao.insertarEstudiante("Master", "Perez", Date.valueOf("1997-04-03"), 7);
     
        System.out.println("\n\n");
     //Prueba de datos para Padre
     PadreDAO pad = new PadreDAO();
     List<Padre> padres = pad.consultarPadres();
        
     for (Padre padr : padres){
            System.out.println(padr);
        }
     
      System.out.println("\n\n");
     //Prueba de datos para Profesor
     ProfesorDAO pro = new ProfesorDAO();
     List<Profesor> profesores = pro.consultarProfesores();
     
     for(Profesor prof : profesores){
         System.out.println(prof);
     }
     
       System.out.println("\n\n");
     //Prueba de datos para CAlificacion
     CalificacionDAO cal = new CalificacionDAO();
     List<Calificacion> calificaciones = cal.consultarCalificaciones();
     
     for(Calificacion cali : calificaciones){
         System.out.println(cali);
     }
     
     System.out.println("\n\n");
     //Prueba de datos para Asistencia
     AsistenciaDAO asi = new AsistenciaDAO();
     List<Asistencia> asistencias = asi.consultarAsistencias();
     
     for(Asistencia asist : asistencias){
         System.out.println(asist);
     }
     
     //Menu m = new Menu();
     SwingUtilities.invokeLater(() -> {
            JFrame ventana = new JFrame("Gestion Escolar");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setSize(580, 400);
            ventana.setLocationRelativeTo(null); // Centrar ventana

            // Agregar el panel personalizado
            ventana.add(new Menu());

            ventana.setVisible(true);
        });
     
    
    }
}
