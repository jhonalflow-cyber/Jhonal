/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;
import Conexion.AdministradorBD;
import Conexion.ConexionBD;
import Conexion.MySQLBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Laptop
 */
public class CalificacionDAO {
    private ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
    private AdministradorBD admin = new AdministradorBD(con);
    
 public void insertarCalificacion(int estudianteId, String materia, double nota, Date fecha) {
        String sql = "INSERT INTO Calificaciones (estudiante_id, materia, nota, fecha) VALUES (?, ?, ?, ?)";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, estudianteId);
            stmt.setString(2, materia);
            stmt.setDouble(3, nota);
            stmt.setDate(4, fecha);

            stmt.executeUpdate();
            System.out.println("Calificación insertada correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Calificacion> consultarCalificaciones() {
        List<Calificacion> lista = new ArrayList<>();
        String sql = "SELECT * FROM Calificaciones";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Calificacion c = new Calificacion();
                c.setId(rs.getInt("id"));
                c.setEstudianteId(rs.getInt("estudiante_id"));
                c.setMateria(rs.getString("materia"));
                c.setNota(rs.getDouble("nota"));
                c.setFecha(rs.getDate("fecha"));
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void actualizarCalificacion(int id, int estudianteId, String materia, double nota, Date fecha) {
        String sql = "UPDATE Calificaciones SET estudiante_id = ?, materia = ?, nota = ?, fecha = ? WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, estudianteId);
            stmt.setString(2, materia);
            stmt.setDouble(3, nota);
            stmt.setDate(4, fecha);
            stmt.setInt(5, id);

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Calificación actualizada correctamente.");
            } else {
                System.out.println("No existe calificación con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
       public void actualizarCalificacionOb(int id, String materia, double nota, Date fecha) {
        String sql = "UPDATE Calificaciones SET materia = ?, nota = ?, fecha = ? WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, materia);
            stmt.setDouble(2, nota);
            stmt.setDate(3, fecha);
            stmt.setInt(4, id);

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Calificación actualizada correctamente.");
            } else {
                System.out.println("No existe calificación con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public List<Object[]> cargarCalificacionesEnTablaOb() {
    List<Object[]> lista = new ArrayList<>();

    String sql = """
        SELECT 
                c.id AS ID, 
                CONCAT(e.nombre, ' ', e.apellido) AS Estudiante,
                c.materia AS Materia,
                c.nota AS Calificacion,
                c.fecha AS Fecha,
                p.nombre AS Profesor
            FROM calificaciones c
            JOIN estudiantes e ON c.estudiante_id = e.id
            JOIN profesores p ON c.materia = p.especialidad;
    """;

    try (Connection a = admin.getConnection();
         Statement st = a.createStatement();
         ResultSet rs = st.executeQuery(sql)) {

        while (rs.next()) {
            Object[] fila = new Object[6];
            fila[0] = rs.getInt("ID");
            fila[1] = rs.getString("Estudiante");
            fila[2] = rs.getString("Materia");
            fila[3] = rs.getString("Calificacion");
            fila[4] = rs.getString("Fecha");
            fila[5] = rs.getString("Profesor");
            lista.add(fila);
            System.out.println(fila[0]+" "+fila[1]+" "+fila[2]+" "+fila[3]+" "+fila[4]+" "+fila[5]);
        }

    } catch (SQLException e) {
        System.out.println("❌ Error al cargar datos: " + e.getMessage());
    }

    return lista;
}

    public void eliminarCalificacion(int id) {
        String sql = "DELETE FROM Calificaciones WHERE id = ?";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Calificación eliminada correctamente.");
            } else {
                System.out.println("No existe calificación con id " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
