/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestion;
import Conexion.AdministradorBD;
import Conexion.ConexionBD;
import Conexion.MySQLBD;
import Conexion.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Laptop
 */

public class EstudianteDAO {
    ConexionBD con = new MySQLBD("localhost",3306,"escuela","root","");
    //ConexionBD con = new SQLiteBD("escuela.db");
    AdministradorBD admin = new AdministradorBD(con);
    

// INSERTAR
    public void insertarEstudiante(String nombre, String apellido, Date fechaNacimiento, int grado) {
        String sql = "INSERT INTO Estudiantes (nombre, apellido, fecha_nacimiento, grado) VALUES (?, ?, ?, ?)";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            stmt.setDate(3, fechaNacimiento);
            stmt.setInt(4, grado);

            stmt.executeUpdate();
            System.out.println("✅ Estudiante insertado correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Estudiante> consultarEstudiantes() {
        List<Estudiante> estudiantes = new ArrayList<>();
        String sql = "SELECT * FROM Estudiantes";

        try (Connection a = admin.getConnection();
             PreparedStatement stmt = a.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Estudiante est = new Estudiante(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getDate("fecha_nacimiento"),
                    rs.getInt("grado")
                );
                estudiantes.add(est);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return estudiantes;
    }
    
     // ACTUALIZAR
    public void actualizarEstudiante(int id, String nombre, String apellido, Date fechaNacimiento, int grado) {
        String sql = "UPDATE Estudiantes SET nombre = ?, apellido = ?, fecha_nacimiento = ?, grado = ? WHERE id = ?";

        try (Connection con = admin.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            stmt.setDate(3, fechaNacimiento);
            stmt.setInt(4, grado);
            stmt.setInt(5, id);

            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("✅ Estudiante actualizado correctamente.");
            } else {
                System.out.println("⚠️ No se encontró el estudiante con ID: " + id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ELIMINAR
    public void eliminarEstudiante(int id) {
        String sql = "DELETE FROM Estudiantes WHERE id = ?";

        try (Connection con = admin.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("✅ Estudiante eliminado correctamente.");
            } else {
                System.out.println("⚠️ No se encontró el estudiante con ID: " + id);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}