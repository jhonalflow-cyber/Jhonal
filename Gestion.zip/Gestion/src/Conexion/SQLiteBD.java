package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Laptop
 */
public class SQLiteBD implements ConexionBD{
    
    private String dbPath;

    public SQLiteBD(String dbPath) {
        this.dbPath = dbPath;
    }

    public Connection connect() throws SQLException {
        System.out.println(dbPath);
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }
}
