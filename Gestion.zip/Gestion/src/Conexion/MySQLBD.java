package Conexion;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 *
 * @author Laptop
 */
public class MySQLBD implements ConexionBD{
    
    private String url;
    private String user;
    private String password;
    
    public MySQLBD(String host, int port, String dbName, String user, String password) {
        this.url = "jdbc:mysql://" + host + ":" + port + "/" + dbName;
        this.user = user;
        this.password = password;
        //Driver de MYSQL
     
    }

    public Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}
