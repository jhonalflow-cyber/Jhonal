
package Conexion;

//import com.sun.jdi.connect.spi.Connection;
//import com.sun.jdi.*;
import java.util.*;
//import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

/**
 *
 * @author Laptop
 */
public class BD {
    
   static String url="jdbc:mysql://localhost:3306/formulariodb";
   static String user="root";
   static String pass="";
    
    public static Connection conectar()
    {
       Connection con=null;
       try
       {
       
           con = DriverManager.getConnection(url,user,pass);
           System.out.println("Conexión exitosa");
       }catch(SQLException e)
       {
        e.printStackTrace();
       }
       
       return con;
               
    }
  
}

