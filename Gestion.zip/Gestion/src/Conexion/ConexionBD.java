package Conexion;


import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;



/**
 *
 * @author Laptop
 */
public interface ConexionBD {
    Connection connect() throws SQLException;
    
}


