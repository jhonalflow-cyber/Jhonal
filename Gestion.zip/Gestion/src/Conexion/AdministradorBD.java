package Conexion;


import java.sql.Connection;
import java.sql.SQLException;


/**
 *
 * @author Laptop
 */
public class AdministradorBD {
    
    private ConexionBD conectar;

    public AdministradorBD(ConexionBD conectar) {
        this.conectar = conectar;
    }

    public Connection getConnection() throws SQLException {
        return conectar.connect();
    }
}
